#include <source.h>

Image* Source::GetOutput()
{
    return &img;
}

/*
Source::Source()
{
    img.setCallback(&Update);    
}
*/
