#include <sink.h>

void Sink::SetInput(Image * i)
{
    img1 = i;
}

void Sink::SetInput2(Image * i)
{
    img2 = i;
}
